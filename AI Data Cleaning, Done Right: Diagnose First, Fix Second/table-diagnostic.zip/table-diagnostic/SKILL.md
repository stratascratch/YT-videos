---
name: table-diagnostic
description: Diagnose messy tabular data (CSV, DataFrame, spreadsheet) before cleaning it. Use whenever the user hands over raw data and asks to clean, prepare, audit, or check the quality of it, or asks "what's wrong with this data" — even if they don't say "diagnose" or name a specific problem. Surfaces near-duplicate categorical values, type mismatches (a column holding a fundamentally different kind of value than it's supposed to, including inconsistent formats within one type), and numeric distributions that suggest a measurement or unit error rather than real variance. Produces a findings report plus reviewable fix code — never applies changes automatically.
---

# Data Diagnostic

A skill for finding the data-quality problems that are easy to miss and slow to hunt down by hand — before touching the data.

## Core principle

Diagnose first, fix second, apply only on request. Every run of this skill produces two things, in order:

1. **A findings report** — what's wrong, in which column, how confident the check is, and why. Nothing about the data changes at this stage.
2. **Proposed fix code** — a plain, readable script (or snippet) that would resolve each finding, shown to the user before it runs. Never execute the fix automatically; always let the user review or edit it first.

Never silently drop rows, fill values, or "auto-clean" without producing the report and code above first.

## What to check

For each column, run the checks that apply to its type:

**Categorical / string columns — near-duplicate values**
- Normalize case, punctuation, and whitespace, then compare values.
- Reconcile against known reference values where they exist (e.g. US state names/abbreviations, country codes, standard unit labels) before falling back to string similarity — reference lookups are far more reliable than similarity alone for small, well-known category sets.
- Only flag a cluster when there's a real basis for calling values "the same" — don't force unrelated short strings together on weak similarity scores. Concretely: skip fuzzy/similarity matching for strings under about 4 characters entirely (two- and three-letter codes collide too easily under any similarity score to trust one), and rely on exact reference-list hits for those instead.
- Never merge values whose digits differ (e.g. "Plan 1" and "Plan 2") — high string similarity isn't evidence they're the same category when a number is the part that's different.

**Columns with type mismatches**
- First check whether every value is actually the kind of thing the column is supposed to hold — a "date" column with placeholder text like "TBD" or "unknown" mixed in, a "numeric" column with entries that don't coerce to a number, and so on. This is a genuine type mismatch (some rows hold a fundamentally different kind of value), not just a formatting quirk — call it that in the report, don't soften it to "some values look off."
- Separately, within the values that ARE the right kind, check for inconsistent formatting (e.g. two different date formats, "$1,200" vs "1200"). This is a real but distinct issue from a true type mismatch — label it as a format inconsistency, not a type mismatch, so the report doesn't conflate the two.
- If a minority of rows fail either check, flag those rows specifically rather than reporting a vague "some values look wrong."
- Report the fraction of affected rows and a few concrete examples.

**Numeric columns — distribution anomalies**
- Use a standard outlier rule (e.g. IQR-based fences) to find values far outside the normal spread. IQR outliers alone are not a finding — a wide or skewed spread can be real variance, not an error.
- An outlier only counts as a unit-error cluster if it's separated from the rest of the values by a real, empty gap (roughly 2x or more) — not just "beyond the fence." A natural long tail is continuous and has no such gap, even when a boundary value happens to land close to a "round" ratio; don't let one borderline point drag a real tail into a false-positive cluster. Points beyond the fence that aren't part of a gap-separated cluster should be reported separately as likely genuine tail values, not folded into the same finding.
- Within the gap-separated cluster, check whether it sits at a consistent multiple of the typical value (e.g. ~10x, ~60x) — that consistent multiple, combined with the separating gap, is the signature of a unit or measurement error, not organic variance, and should be reported with that distinction explicit.
- Don't recommend dropping these rows by default; recommend flagging them for review, since the "fix" (rescale vs. drop vs. keep) depends on context the data alone doesn't give you.

## Output format

Report each finding with: column, issue type, detail (specific values/rows/counts, not just "issue found"), and a confidence level with a one-line reason for that confidence.

For fixes, write one code block per finding: readable variable names, a comment above each step explaining what it does, and no line that modifies the data without the corresponding finding being reported first.

## When NOT to over-flag

- A column with natural, wide-but-real variance (e.g. income, page views) is not a distribution anomaly — only flag when there's a distinct, gap-separated cluster suggesting a mechanical cause, not just a wide spread. This is a real failure mode, not a theoretical one: an unconstrained outlier check will flag ordinary skewed data as a fake unit error if it doesn't require that separating gap.
- Don't invent findings to pad the report. If a column looks clean, say so.
